<?php

    require ('database.php');

    // scripts de connexion de comptes utilisateurs
    if (!empty($_POST['username']) && !empty($_POST['password'])) { // si les champs ne sont pas vides
        // on récupère les informations de connexion entrées par l'utilisateur
        $username = $_POST['username'];
        $password = $_POST['password'];
        
        // vérifions si l'utilisateur existe(est inscrit dans la base de données)
        $searchUser = $db->prepare('SELECT * FROM users WHERE username = ? AND password = ?');
        $searchUser->execute(array($username, $password));
        if ($connectedInfos = $searchUser->fetch()) { // si l'utilisateur est inscrit et que ses coordonnées sont juste alors on le connecte
            session_start();
            // on stocke les infos de l'utilisateur connecté des la session
            $_SESSION['id'] = $connectedInfos['id'];
            $_SESSION['firstname'] = $connectedInfos['firstname'];
            $_SESSION['lastname'] = $connectedInfos['lastname'];
            $_SESSION['username'] = $connectedInfos['username'];
            // $_SESSION['status'] = $connectedInfos['status'];

            // on modifie le champs status a actif 
            $actifStatus = $db->prepare('UPDATE users SET status = ? WHERE id = ?');
            $actifStatus->execute(array(1, $_SESSION['id']));

            if ($actifStatus) {
                echo 'succes';
            }
        }else {
            echo 'Username ou mot de passe incorrect(s).';
        }
    }else {
        echo 'Veuillez renseigner tous les champs.';
    }

?>