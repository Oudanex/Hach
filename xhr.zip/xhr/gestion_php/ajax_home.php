<?php

    require('get_users.php');
    
    if (isset($minichatUsers)) {
        foreach ($minichatUsers as $minichatUser) {
            ?>

                <div class="user">
                    <img src="img/beauty-354565_1280.jpg" alt="" id="userImg">                   
                    <a href="chat.php?receiverId=<?= $minichatUser['id']; ?>" id="userColor"><?= $minichatUser['firstname'] . ' ' . $minichatUser['lastname']; ?></a>
                    <?php
                    
                        if ($minichatUser['status'] == 1) {
                            ?>
                                <div class="status actif"></div>  
                            <?php        
                        }else {
                            ?>
                            <div class="status inactif"></div>
                            <?php
                        }
                    
                    ?>
                </div>

            <?php
        }   
    }else{
        ?>
            <div class="noUser">
                <span>Aucun utilisateur trouvé !</span>
                <a href="index.php" class="m-blue">Actualiser</a>
            </div>
        <?php
    }

?>