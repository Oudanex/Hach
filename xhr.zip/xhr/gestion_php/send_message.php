<?php

    session_start();
    require ('get_users.php');

    if (!empty($_POST['selUser']) && !empty($_POST['content'])) {
        foreach ($minichatUsers as $minichatUser) {
            if ($minichatUser['username'] == $_POST['selUser'] || $minichatUser['firstname'] . ' ' . $minichatUser['lastname'] == $_POST['selUser']) {
                $found = true;
                $receiverId = $minichatUser['id'];
            }else{
                $not_found = true;
            }
        }
    }else {
        echo 'Veuillez renseigner tous les champs.';
    }

    if (isset($found) && $found) {
        $insertMsg = $db->prepare('INSERT INTO messages(sender_id, receiver_id, message) VALUES(?, ?, ?)');
        $insertMsg->execute(array($_SESSION['id'], $receiverId, $_POST['content']));

        if ($insertMsg) {
            echo 'succes';
        }
    }
    if (isset($not_found) && ! isset($found)) {
        echo 'Aucun utilisateur trouvé.';
    }

?>