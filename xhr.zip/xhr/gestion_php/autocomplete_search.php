<?php

    session_start();
    require ('get_users.php');

    if (!empty($_POST['searchValue'])) {
        foreach ($minichatUsers as $minichatUser) {

            // tester si les mots de la recherche sont contenus dans les infos de l'utilisateur à rechercher
            // $username_test = str_contains($minichatUser['username'], $_POST['searchValue']);
            // $firstname_test = str_contains($minichatUser['firstname'], $_POST['searchValue']);
            // $lastname_test = str_contains($minichatUser['lastname'], $_POST['searchValue']);
            
            $username_test = str_starts_with($minichatUser['username'], $_POST['searchValue']);
            $firstname_test = str_starts_with($minichatUser['firstname'], $_POST['searchValue']);
            $lastname_test = str_starts_with($minichatUser['lastname'], $_POST['searchValue']);
            $fullname_test = str_starts_with($minichatUser['firstname'] . ' ' . $minichatUser['lastname'], $_POST['searchValue']);

            if ($username_test) {
                echo '<li>' . $minichatUser['username'] . '</li>';
                $found = true;
            }elseif ($firstname_test) {
                echo '<li>' . $minichatUser['firstname'] . ' ' . $minichatUser['lastname'] . '</li>';
                $found = true;
            }elseif ($lastname_test) {
                echo '<li>' . $minichatUser['firstname'] . ' ' . $minichatUser['lastname'] . '</li>';
                $found = true;
            }elseif ($fullname_test) {
                echo '<li>' . $minichatUser['firstname'] . ' ' . $minichatUser['lastname'] . '</li>';
                $found = true;
            }else {
                $not_found = true;
            }
        }
    }

    if (isset($not_found) && ! isset($found)) {
        echo 'not_found';
    }


    // je fais tous c'que je peux pour ne pas faire trop de requetes sql
?>