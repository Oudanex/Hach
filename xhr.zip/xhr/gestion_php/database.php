<?php

    $db = new PDO('mysql:host=localhost;dbname=minichat;charset=utf8', 'root', '');

?>