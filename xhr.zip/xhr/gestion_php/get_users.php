<?php
    
    require ('database.php');
    
    // recherche des utilisateurs de minichat
    $selUsers = $db->prepare('SELECT * FROM users WHERE username != ?');
    $selUsers->execute(array($_SESSION['username']));
    
    if ($selUsers->rowCount() > 0) {
        while ($users = $selUsers->fetch()) {
            $minichatUsers[] = $users;
        }
    }
    
?>