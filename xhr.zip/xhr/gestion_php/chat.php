<?php

    require ('get_users.php');

    // code pour obtenir l'utitlisateur (receiver)    
    if (isset($_GET['receiverId'])) {
        foreach ($minichatUsers as $minichatUser) {
            if ($minichatUser['id'] == $_GET['receiverId']) {
                $receiver = htmlspecialchars($minichatUser['firstname']) . ' ' . htmlspecialchars($minichatUser['lastname']);

                if ($minichatUser['status'] == 1) {
                    $status = 'actif';
                }else{
                    $status = 'inactif';
                }
            }
        }
    }

    // code d'envoie de message
    if (isset($_POST['sendMsg'])) {
        if (!empty($_POST['message'])) {
            $insertMsg = $db->prepare('INSERT INTO messages(sender_id, receiver_id, message) VALUES(?, ?, ?)');
            $insertMsg->execute(array($_SESSION['id'], $_GET['receiverId'], $_POST['message']));
        }else{
            // echo 'Message vide.';
        }
    }
    // recherche des messages
    $searchMsg = $db->prepare('SELECT * FROM messages');
    $searchMsg->execute();

    while ($msg = $searchMsg->fetch()) {
        $messages[] = $msg;
    }
    
?>