<?php

    require('get_users.php');
    
    if (isset($minichatUsers)) {
        $friend_count = 0;

        foreach ($minichatUsers as $minichatUser) {
            $is_added = $db->prepare('SELECT * FROM friends WHERE user_id = ? AND friend_id = ? OR user_id = ? AND friend_id = ?');
            $is_added->execute(array($_SESSION['id'], $minichatUser['id'], $minichatUser['id'], $_SESSION['id']));
            
            if ($is_added->rowCount() == 0) {
                $user_friend = $db->prepare('SELECT * FROM friends WHERE user_id = ? AND status = ?');
                $user_friend->execute(array($minichatUser['id'], 1));

                if ($user_friend->rowCount() > 0) {
                    while ($friend = $user_friend->fetch()) {
                        $friend_count++;
                    }
                }else {
                    $friend_count = 0;
                }

                ?>
                    <div class="user add">
                        <div class="first">
                            <img src="img/alone-4480437_1280.jpg" alt="">
                            <a href="#" id="username"><?= $minichatUser['firstname'] . ' ' . $minichatUser['lastname']; ?></a>
                            <p><?= $friend_count . ' friends'; ?></p>
                        </div>
                        <div class="addBtn">
                            <a href="send_invitation.php?user_id=<?= $minichatUser['id']; ?>&s=1" id="send">Ajouter comme ami(e)</a>
                        </div>
                    </div>
                <?php
            }else {
                if (isset($_GET['user_id']) && isset($_GET['sent_invitation'])) {
                    if ($minichatUser['id'] == $_GET['user_id']) {
                        ?>
                            <div class="user add">
                                <div class="first">
                                    <img src="img/alone-4480437_1280.jpg" alt="">
                                    <a href="#" id="username"><?= $minichatUser['firstname'] . ' ' . $minichatUser['lastname']; ?></a>
                                    <p><?= $friend_count . ' friends'; ?></p>
                                </div>
                                <div class="addBtn">
                                    <p id="sent">Invitation envoyée</p>
                                </div>
                            </div>
                        <?php
                    }
                }
            }
        }
    }

?>