<?php

    require ('database.php');

    // scripts de création de comptes utilisateurs
    if (!empty($_POST['firstname']) && !empty($_POST['lastname']) && !empty($_POST['username']) && !empty($_POST['password'])) { // si l'utilisateur remplit tous les champs
        // on stocke les entrés de l'utilisateur dans des variables
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $username = $_POST['username'];
        $password = $_POST['password'];

        // verifions si il n'y a pas d'utilisateur inscrit utilisant les memes coordonnées
        $verifUser = $db->prepare('SELECT * FROM users WHERE username = ?');
        $verifUser->execute(array($username));
        if ($verifUser->fetch()) { // si on trouve un utilisateur alors on envoie un message qui sera récupéré dans inscription.js
            echo 'Username déjà utilisé par un autre compte.';
        }else { // sinon si tous va bien et que l'utilisateur n'existe pas encore alors on le crée
            $createUser = $db->prepare('INSERT INTO users(firstname, lastname, username, password, status) VALUES(?, ?, ?, ?, ?)');
            $createUser->execute(array($firstname, $lastname, $username, $password, 0));
            if ($createUser) { // si l'utilisateur est bien inséré dans la base de données alors on le redirige vers la page de connexion avec un message
                echo 'succes';
            }
        }
    }else {
        echo 'Veuillez renseigner tous les champs.';
    }

?>