<?php

	require 'database.php';

	$get_friends = $db->prepare('SELECT * FROM friends WHERE user_id = ? AND status = ? OR friend_id = ? AND status = ?');
	$get_friends->execute(array($_SESSION['id'], 1, $_SESSION['id'], 1));

	if ($get_friends->rowCount() > 0) {
		while ($friend = $get_friends->fetch()) {
			$friends[] = $friend;
		}

		foreach ($friends as $friend) {
			$get_friend_infos = $db->prepare('SELECT * FROM users WHERE id = ?');

			if ($friend['user_id'] == $_SESSION['id']) {
				$get_friend_infos->execute(array($friend['id']));	
			}elseif ($friend['friend_id'] == $_SESSION['id']) {
				$get_friend_infos->execute(array($friend['user_id']));
			}

			if ($friend_infos = $get_friend_infos->fetch()) {
				$friend_fullname = $friend_infos['firstname'] . ' ' . $friend_infos['lastname'];
				$status = ($friend_infos['status'] == 1) ? '<div class="status actif"></div>' : '<div class="status inactif"></div>';
			}

			?>
				<div class="user">
					<img src="img/beauty-354565_1280.jpg" alt="" id="userImg">
					<a href="chat.php?receiver_id=<?= $friend['id']; ?>" id="userColor"><?= $friend_fullname ?></a>
					<?= $status ?>
				</div>
			<?php
		}
	}else {
		echo 'not_found';
	}

?>