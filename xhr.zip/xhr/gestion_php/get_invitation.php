<?php

    require('database.php');

    $received_invitation_count = 0;
    $sent_invitation_count = 0;

    $get_received_invitation = $db->prepare('SELECT * FROM friends WHERE friend_id = ? AND status = ? ORDER BY id DESC');
    $get_received_invitation->execute(array($_SESSION['id'], 0));

    while ($invitation = $get_received_invitation->fetch()) {
        $received_invitations[] = $invitation;
        $received_invitation_count++;
    }

    $get_sent_invitation = $db->prepare('SELECT * FROM friends WHERE user_id = ? AND status = ? ORDER BY id DESC');
    $get_sent_invitation->execute(array($_SESSION['id'], 0));

    while ($invitation = $get_sent_invitation->fetch()) {
        $sent_invitations[] = $invitation;
        $sent_invitation_count++;
    }

?>