<?php

    session_start();
    require ('gestion_php/database.php');

    if (isset($_GET['user_id'])) {

        $verifFriend = $db->prepare('SELECT * FROM friends WHERE user_id = ? AND friend_id = ? AND status = ?');
        $verifFriend->execute(array($_SESSION['id'], $_GET['user_id'], 0));

        if ($verifFriend->rowCount() == 0) {

            $searchFriend = $db->prepare('SELECT * FROM users WHERE id = ? AND id != ?');
            $searchFriend->execute(array($_GET['user_id'], $_SESSION['id']));

            if ($searchFriend->rowCount() == 1) {
                $insertFriend = $db->prepare('INSERT INTO friends(user_id, friend_id, status) VALUES(?, ?, ?)');
                $insertFriend->execute(array($_SESSION['id'], $_GET['user_id'], 0));

                if ($insertFriend) {
                    header('Location: test.php?sent_invitation&user_id='. $_GET['user_id']);
                }   
            }else {
                echo 'Utilisateur introuvable.';
            }
        }else {
            header('Location: error404.php');
        }
    }else{
        echo 'Page introuvable.';
    }

?>