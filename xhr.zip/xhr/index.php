<?php

    session_start();
    
    if (! isset($_SESSION['id'])) {
        header('Location: login.php');
    }else{
        // nom complet de l'utilisateur
        $connectedName = htmlspecialchars($_SESSION['firstname']) . ' ' . htmlspecialchars( $_SESSION['lastname']);
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="style/all.min.css">
    <title>MiniChat | Acceuil : Utilisateurs de MiniChat</title>
</head>
<body>
    <div class="container">
        <div class="header b-btm">
            <h1>MiniChat</h1>
        </div>
        <div class="connectedUser b-btm">
            <div class="profil">
                <img src="img/alone-4480436_1280.jpg" alt="" id="userImg">
                <a href="#" id="userColor"><?= $connectedName; ?></a>
                <div class="status actif"></div>
            </div>
            <i class="fa-solid fa-gear"></i>
        </div>

        <div class="menu">
            <ul>
                <li>
                    <a href="account.html">Account</a>
                </li>
                <li>
                    <a href="send_message.php">Message</a>
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
        <p class="title">UTILISATEURS DE MINICHAT</p>
        <div class="users">
            <?php
            
                require ('gestion_php/ajax_home.php');
            
            ?>
        </div>  
    </div>

    <script src="js/home.js" defer></script>
</body>
</html>