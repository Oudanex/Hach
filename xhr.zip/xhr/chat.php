<?php

    session_start();

    // inclure le fichier contenant tous le code sur la page de messageriesss
    require ('gestion_php/chat.php');

    if (!isset($_SESSION['id'])) {
        header('Location: login.php');
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="style/all.min.css">
    <title>MiniChat | Inbox : <?= $receiver; ?></title>
</head>
<body>
    <div class="container">
        <div class="receiver b-btm">
            <div class="profil">
                <a href="index.php">
                    <i class="fa-solid fa-arrow-left"></i>
                </a>
                <img src="img/alone-4480437_1280.jpg" alt="" id="userImg">
                <?php

                    if (isset($receiver)) {
                        ?>
                        <a href="#" id="userColor"><?= $receiver; ?></a>
                        <?php
                    }else {
                        header('Location: index.php');
                    }

                ?>    
                <div class="status <?= $status; ?>"></div>
            </div>
            <i class="fa-solid fa-gear"></i>
        </div>
        <div class="msgBox"> 
        <?php  
            if (isset($messages)) {
                foreach ($messages as $message) {
                    if ($message['sender_id'] == $_SESSION['id'] && $message['receiver_id'] == $_GET['receiverId']) {
                        ?>
                        <div class="sent" id="msg"><?= nl2br(htmlspecialchars($message['message'])); ?></div>
                        <?php
                        $sent = 1;
                    }elseif ($message['sender_id'] == $_GET['receiverId'] && $message['receiver_id'] == $_SESSION['id']) {
                        ?>
                        <div class="received" id="msg"><?= nl2br(htmlspecialchars($message['message'])); ?></div>
                        <?php
                        $received = 1;
                    }
                }
            }
            if (!isset($sent) && !isset($received)) {
                ?>
                <div class="noMsg">Les messages envoyés et reçus seront affichés ici.</div>
                <?php
            }

        ?>    
        </div>
        <form method="post" class="sendMsg">
            <input type="text" name="message" id="msgInput" placeholder="Message" autocomplete="off">
            <button type="submit" name="sendMsg" id="sendBtn">
                <i class="fa-solid fa-paper-plane"></i>
            </button>
        </form>
    </div>
    <script src="js/chat_page.js" defer></script>
</body>
</html>