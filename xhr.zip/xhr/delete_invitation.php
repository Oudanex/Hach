<?php

    session_start();
    require ('gestion_php/database.php');

    if (isset($_GET['user_id'])) {
        $delete = $db->prepare('DELETE FROM friends WHERE user_id = ? AND friend_id = ?');
        
        if (isset($_GET['delete_sent'])) {
            $delete->execute(array($_SESSION['id'], $_GET['user_id']));
        }elseif (isset($_GET['delete_received'])) {
            $delete->execute(array($_GET['user_id'], $_SESSION['id']));
        }

        if ($delete) {
            header('Location: invitations.php');
        }
    }else {
        echo 'Page introuvable.';
    }

?>