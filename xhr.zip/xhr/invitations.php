<?php

    session_start();

    require ('gestion_php/get_invitation.php');

    if (! isset($_SESSION['id'])) {
        header('Location: login.php');
    }else {
        $connectedName = htmlspecialchars($_SESSION['firstname']) . ' ' . htmlspecialchars( $_SESSION['lastname']);
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="style/all.min.css">
    <title>MiniChat | Liste des invitations</title>

    <style>
        .main{
            max-height: 300px;
            overflow-x: auto;
        }
        .main::-webkit-scrollbar{
            width: 0;
        }
        .group .type{
            display: flex;
            align-items: center;
            gap: 6px;
            background-color: #f1f1f1;
            padding: 8px 10px;
            color: #6e6d6d;
        }
        .group .type i{
            color: #6e6d6d;
        }
        .group .child{
            display: grid;
            grid-template-rows: 1fr;
            grid-template-rows: 1fr;
            grid-template-areas: 
                'img text'
                'img opts';
            background-color: #d1e7dc52;
            padding: 8px;
            padding-bottom: 15px;
            border-width: 2px;
            width: 100%;
        }
        .group .child img{
            grid-area: img;
            width: 50px;
        }
        .group .child p{
            grid-area: text;
            margin-bottom: 15px;
            margin-left: 5px;
        }
        .group .child p span{
            font-size: 1em;
            font-weight: 600;
        }
        .group .child .options{
            grid-area: opts;
            margin-left: 5px;
        }
        .group .child .options a:first-child{
            background: linear-gradient(to top, #167a9e 95%, #167a9ea8);
            color: #fff;
            border: 1px solid #167a9ea8;
            border-bottom: 0;
            border-radius: 5px;
            padding: 5px;
            font-size: 1em;
            cursor: pointer;
            margin-right: 5px;
        }
        .group .child .options a:first-child:active{
            background: linear-gradient(to top, #167a9ed7 95%, #167a9ea8);
        }
        .group .child .options a:last-child{
            background: #d2d6d9;
            color: #3d3d3d;
            border: 1px solid #c1c1c1;
            border-radius: 5px;
            padding: 5px;
            font-size: 1em;
            cursor: pointer;
        }
        .no-inv{
            text-align: center;
            color: #3d3d3d;
            padding: 10px 5px;
        }
        @media screen and (max-width : 414px) {
            .main{
               max-height: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header b-btm">
            <h1>MiniChat</h1>
        </div>      

        <div class="connectedUser">
            <div class="profil">
                <img src="img/alone-4480436_1280.jpg" alt="" id="userImg">
                <a href="#" id="userColor"><?= $connectedName; ?></a>
                <div class="status actif"></div>
            </div>
            <i class="fa-solid fa-gear"></i>
        </div>

        <div class="main">
            <div class="group">
                <div class="type b-btm">
                    <i class="fa-solid fa-user-group"></i>
                    <p>INVITATIONS REÇUES (<?= $received_invitation_count; ?>)</p>
                </div>

                <?php
                
                        if (isset($received_invitations)) {
                            foreach ($received_invitations as $invitation) {
                                $searchUser = $db->prepare('SELECT * FROM users WHERE id = ?');
                                $searchUser->execute(array($invitation['user_id']));
        
                                if ($sender = $searchUser->fetch()) {
                                    $sender_fullname = $sender['firstname'] . ' ' . $sender['lastname'];
                                }

                                ?>
                                    <div class="child">
                                        <img src="img/alone-4480437_1280.jpg" alt="sender profil" id="userImg">
                                        <p>Vous avez reçu une nouvelle invitation de <span><?= $sender_fullname; ?></span>.</p>
                                        <div class="options">
                                            <a href="comfirm_invitation.php?user_id=<?= $invitation['user_id']; ?>">Accepter comme ami(e)</a>
                                            <a href="delete_invitation.php?delete_received&user_id=<?= $sender['id'] ?>">Rejeter</a>
                                        </div>
                                    </div>
                                <?php
                            }
                        }else {
                            echo '<p class="no-inv">Aucune invitation reçue</p>';
                        }
                
                ?>

            </div>

            <div class="group">
                <div class="type b-btm">
                    <i class="fa-solid fa-user-group"></i>
                    <p>INVITATIONS ENVOYÉES (<?= $sent_invitation_count; ?>)</p>
                </div>
                
                <?php
                
                        if (isset($sent_invitations)) {
                            foreach ($sent_invitations as $invitation) {
                                $searchUser = $db->prepare('SELECT * FROM users WHERE id = ?');
                                $searchUser->execute(array($invitation['friend_id']));
        
                                if ($sender = $searchUser->fetch()) {
                                    $sender_fullname = $sender['firstname'] . ' ' . $sender['lastname'];
                                }

                                ?>
                                    <div class="child">
                                        <img src="img/alone-4480437_1280.jpg" alt="sender profil" id="userImg">
                                        <p>Vous avez envoyé une nouvelle invitation à <span><?= $sender_fullname; ?></span>.</p>
                                        <div class="options">
                                            <a href="delete_invitation.php?delete_sent&user_id=<?= $sender['id'] ?>">Annuler l'invitation</a>
                                        </div>
                                    </div>
                                <?php
                            }
                        }else {
                            echo '<p class="no-inv">Aucune invitation envoyée</p>';
                        }
                
                ?>

            </div>
        </div>
    </div>

    <script>
        let child = document.querySelectorAll('.child:not(:last-child)');

        if (child) {
            for (let i = 0; i < child.length; i++) {
                child[i].classList.add('b-btm');            
            }
        }

    </script>
</body>
</html>