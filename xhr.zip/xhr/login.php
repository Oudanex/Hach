<?php

    session_start();

    if (isset($_SESSION['id'])) {
        header('Location: index.php');
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style/style.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="header b-btm">
            <h1>MiniChat | Connexion</h1>
        </div>
        <div class="form">
            <div class="txt"></div>
            <form>
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" id="loginBtn">Se connecter</button>
            </form>
            <div class="link">Vous n'avez pas de compte ? <a href="signup.php">S'inscrire</a></div>
        </div>
    </div>

    <script src="js/login.js" defer></script>
</body>
</html>