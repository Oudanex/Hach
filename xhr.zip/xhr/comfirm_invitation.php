<?php

    session_start();
    require ('gestion_php/database.php');

    if (isset($_GET['user_id'])) {
        $comfirm = $db->prepare('UPDATE friends SET status = ? WHERE user_id = ? AND friend_id = ?');
        $comfirm->execute(array(1, $_GET['user_id'], $_SESSION['id']));

        if ($comfirm) {
            header('Location: invitations.php');
        }
    }else{
        echo 'Page introuvable.';
    }

?>