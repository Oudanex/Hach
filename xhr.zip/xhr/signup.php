<?php

    session_start();

    if (isset($_SESSION['id'])) {
        header('Location: index.php');
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style/style.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="header b-btm">
            <h1>MiniChat | Inscription</h1>
        </div>
        <div class="form">
            <div class="txt"></div>
            <form>
                <div class="names">
                    <input type="text" name="firstname" placeholder="Firstname" required>
                    <input type="text" name="lastname" placeholder="Lastname" required>
                </div>
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" id="sendBtn">S'inscrire</button>
            </form>
            <div class="link">Vous avez un compte ? <a href="login.php">Se connecter</a></div>
        </div>
    </div>
    <script src="js/signup.js" defer></script>
</body>
</html>