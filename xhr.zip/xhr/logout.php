<?php

    session_start();

    require ('gestion_php/database.php');
    if (isset($_SESSION['id'])) {
        $actifStatus = $db->prepare('UPDATE users SET status = ? WHERE id = ?');
        $actifStatus->execute(array(0, $_SESSION['id']));
        if ($actifStatus) {
            $_SESSION = array();
            session_destroy();
            header('Location: login.php');
        }else {
            header('Location: index.php');
        }
    }else {
        header('Location: login.php?href=logout.php&access=denied');
    }

?>    