let msgInput = document.getElementById('msgInput'),
form = document.querySelector('.sendMsg'),
msgBox = document.querySelector('.msgBox'),
msgContent = document.querySelectorAll('#msg'),
sendBtn = document.getElementById('sendBtn');

msgInput.onkeyup = function () {
    if (msgInput.value != '') {
        sendBtn.style.display = 'block';
    }else{
        sendBtn.style.display = 'none';
    }
}

msgContent.forEach(element => {
    if (element.innerText.length < 3) {
        element.style.textAlign = 'center';
        element.style.borderRadius = '50%';
    }
});

msgBox.scrollTop = msgBox.scrollHeight;