let form = document.querySelector('form'),
errorMsg = document.querySelector('.txt'),
suggestions = document.querySelector('.suggestions'),
list = suggestions.querySelector('ul'),
nameInput = document.getElementById('receiver'),
sendBtn = document.getElementById('sendMsg');

form.onsubmit = function (e) {
    e.preventDefault();
}

nameInput.onkeyup = function () {
    let searchValue = nameInput.value;
    errorMsg.style.display = 'none';

    let xhr = new XMLHttpRequest();
    xhr.open('POST', './gestion_php/autocomplete_search.php', true);
    xhr.onload = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            let phpData = xhr.response;

            if (phpData != 'not_found') {
                suggestions.classList.add('show');
                list.innerHTML = phpData;

                let elements = list.querySelectorAll('li');
                if (elements) {
                    elements.forEach(element => {
                        element.onclick = function () {
                            nameInput.value = element.innerText;
                            suggestions.classList.remove('show');
                        }
                        if (nameInput.value == element.innerText) {
                            suggestions.classList.remove('show');
                        }
                    });
                    document.onkeydown = function (e) {
                        if (e.key === 'Tab') {
                            nameInput.value = elements[0].innerText;
                            suggestions.classList.remove('show');
                        }
                    }
                }
            }else{
                suggestions.classList.remove('show');
            }
            if (searchValue == '') {
                suggestions.classList.remove('show');
            } 
        }
    }

    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send('searchValue=' + searchValue);
}

sendBtn.onclick = function () {
    let xhr = new XMLHttpRequest();

    xhr.open('POST', './gestion_php/send_message.php', true);
    xhr.onload = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            let phpData = xhr.response;
            if (phpData == 'succes') {
                errorMsg.classList.remove('txt');
                errorMsg.classList.add('change');

                errorMsg.style.display = 'block';
                errorMsg.innerText = 'Message envoyé avec succes.';
            } else {
                if (errorMsg.classList.contains('change')) {
                    errorMsg.classList.remove('change');
                    errorMsg.classList.add('txt');
                }
                errorMsg.style.display = 'block';
                errorMsg.innerText = phpData;
            }
        }
    }
    let formData = new FormData(form);
    xhr.send(formData);
}