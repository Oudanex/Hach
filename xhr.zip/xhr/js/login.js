let form = document.querySelector('form'),
loginBtn = document.getElementById('loginBtn'),
errorMsg = document.querySelector('.txt');

form.onsubmit = function (e) {
    e.preventDefault();
}

loginBtn.onclick = function () {
    let xhr = new XMLHttpRequest();

    xhr.open('POST', './gestion_php/ajax_login.php', true);
    xhr.onload = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            let phpData = xhr.response;
            
            if (phpData == 'succes') {
                location.href = 'index.php';
            }else{
                errorMsg.style.display = 'block';
                errorMsg.innerText = phpData;
            }
        }
    }
    let formData = new FormData(form);
    xhr.send(formData);
}
