let icon = document.querySelector('.fa-gear'),
title = document.querySelector('.title'),
noUser = document.querySelector('.noUser'),
menu = document.querySelector('.menu');

icon.onclick = function () {
    menu.classList.toggle('show');
}

if (noUser) {
    title.style.display = 'none';
    noUser.style.marginTop = '0';
}
