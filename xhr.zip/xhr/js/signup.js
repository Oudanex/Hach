let form = document.querySelector('form'),
sendBtn = document.getElementById('sendBtn'),
errorMsg = document.querySelector('.txt');

form.onsubmit = function (e) {
    e.preventDefault();
}

sendBtn.onclick = function () {
    let xhr = new XMLHttpRequest();

    xhr.open('POST', './gestion_php/ajax_signup.php', true);
    xhr.onload = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            let phpData = xhr.response;
            
            if (phpData == 'succes') {
                location.href = 'login.php?succes=1&account_creation=true';
            }else{
                errorMsg.style.display = 'block';
                errorMsg.innerText = phpData;
            }
        }
    }
    let formData = new FormData(form);
    xhr.send(formData);
}
