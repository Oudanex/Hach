<?php 

    session_start();
    
    if (! isset($_SESSION['id'])) {
        header('Location: login.php');
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <title>MiniChat | Envoyer un message manuellement</title>
</head>
<body>
    <div class="container">
        <div class="header b-btm">
            <h2>Envoyer un message à : </h2>
        </div>

        <div class="form">
            <div class="txt"></div>
            <form class="content" autocomplete="off">
                <input type="text" name="selUser" id="receiver" placeholder="Entrer un username, nom, prenom...">
    
                <div class="suggestions">
                    <div class="fleche"></div>
                    <ul></ul>
                </div>
    
                <textarea type="text" name="content" id="msgContent" placeholder="Message"></textarea>
                <div class="options">
                    <a href="index.php" id="cancel" class="btn m-blue">Annuler</a>
                    <a id="sendMsg" class="btn">Envoyer</a>
                </div>
            </form>
        </div>
    </div>

    <script src="js/send_message.js" defer></script>
</body>
</html>