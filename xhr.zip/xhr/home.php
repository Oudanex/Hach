<?php

	session_start();

	if (! isset($_SESSION['id'])) {
        header('Location: login.php');
    }else{
        $connectedName = htmlspecialchars($_SESSION['firstname']) . ' ' . htmlspecialchars( $_SESSION['lastname']);
    }

?>	

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>MiniChat | Envoyer un message à vos amis</title>
	<link rel="stylesheet" href="style/style.css">
</head>
<body>
	<div class="container">
		<div class="header b-btm">
            <h1>MiniChat</h1>
        </div>

        <div class="connectedUser">
            <div class="profil">
                <img src="img/alone-4480436_1280.jpg" alt="" id="userImg">
                <a href="#" id="userColor"><?= $connectedName ?></a>
                <div class="status actif"></div>
            </div>
            <i class="fa-solid fa-gear"></i>
        </div>

        <div class="user">
        	<div class="group b-btm">
            	<i class="fa-solid fa-comments"></i>
            	<p>ENVOYER UN MESSAGE A VOS AMIS</p>
        	</div>

        	<div class="users">
        		<?php require 'gestion_php/get_friends.php'; ?>
            </div>
        </div>
	</div>
</body>
</html>